<?php
require 'auth.php';
require 'config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare('DELETE FROM products WHERE id=?');
            $stmt->execute([$id]);
            header('Location: products.php'); exit;
        } catch (PDOException $e) { $error = 'Cannot delete a product that already has sales records.'; }
    } else {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $sku = trim($_POST['sku'] ?? '');
        $price = (float)($_POST['price'] ?? 0);
        $stock = (int)($_POST['stock'] ?? 0);
        if ($name === '' || $sku === '' || $price < 0 || $stock < 0) {
            $error = 'Please enter valid product details.';
        } else {
            try {
                if ($id > 0) {
                    $stmt = $pdo->prepare('UPDATE products SET name=?, sku=?, price=?, stock=? WHERE id=?');
                    $stmt->execute([$name,$sku,$price,$stock,$id]);
                } else {
                    $stmt = $pdo->prepare('INSERT INTO products (name,sku,price,stock) VALUES (?,?,?,?)');
                    $stmt->execute([$name,$sku,$price,$stock]);
                }
                header('Location: products.php'); exit;
            } catch (PDOException $e) { $error = 'Could not save. Make sure the SKU is unique.'; }
        }
    }
}
$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}
$products = $pdo->query('SELECT * FROM products ORDER BY name')->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Products | StorePOS</title><link rel="stylesheet" href="assets/style.css"></head><body>
<?php include 'nav.php'; ?><main class="container">
<div class="page-heading"><div><p class="eyebrow">CATALOG</p><h1>Products</h1><p class="muted">Manage products, prices, and stock.</p></div></div>
<?php if ($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<section class="panel"><h2><?= $edit ? 'Edit product' : 'Add a product' ?></h2>
<form method="post" class="form-grid">
<input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
<label>Product name<input name="name" required value="<?= htmlspecialchars($edit['name'] ?? '') ?>"></label>
<label>SKU / Code<input name="sku" required value="<?= htmlspecialchars($edit['sku'] ?? '') ?>"></label>
<label>Price (₱)<input type="number" name="price" min="0" step="0.01" required value="<?= htmlspecialchars($edit['price'] ?? '') ?>"></label>
<label>Stock quantity<input type="number" name="stock" min="0" required value="<?= htmlspecialchars($edit['stock'] ?? '') ?>"></label>
<div class="form-actions"><button class="btn" type="submit">Save product</button><?php if ($edit): ?><a class="btn secondary" href="products.php">Cancel</a><?php endif; ?></div>
</form></section>
<section class="panel"><h2>Product list</h2><div class="table-wrap"><table><thead><tr><th>Product</th><th>SKU</th><th>Price</th><th>Stock</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($products as $p): ?><tr><td><?= htmlspecialchars($p['name']) ?></td><td><?= htmlspecialchars($p['sku']) ?></td><td>₱<?= number_format($p['price'],2) ?></td><td><?= (int)$p['stock'] ?><?php if ($p['stock'] <= 5): ?> <span class="low-stock">Low</span><?php endif; ?></td><td class="actions"><a href="products.php?edit=<?= (int)$p['id'] ?>">Edit</a><form method="post" onsubmit="return confirm('Delete this product?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="link-danger" type="submit">Delete</button></form></td></tr><?php endforeach; ?>
<?php if (!$products): ?><tr><td colspan="5">No products found.</td></tr><?php endif; ?>
</tbody></table></div></section></main></body></html>
