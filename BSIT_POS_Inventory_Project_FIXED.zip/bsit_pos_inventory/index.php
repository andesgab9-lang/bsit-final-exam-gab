<?php
require 'auth.php';
require 'config.php';

$productCount = (int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
$stockCount = (int)$pdo->query('SELECT COALESCE(SUM(stock),0) FROM products')->fetchColumn();
$todaySales = (float)$pdo->query('SELECT COALESCE(SUM(total),0) FROM sales WHERE DATE(sold_at)=CURDATE()')->fetchColumn();
$recent = $pdo->query('SELECT s.*, p.name AS product_name FROM sales s JOIN products p ON p.id=s.product_id ORDER BY s.sold_at DESC LIMIT 8')->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard | StorePOS</title><link rel="stylesheet" href="assets/style.css"></head><body>
<?php include 'nav.php'; ?>
<main class="container">
  <div class="page-heading"><div><p class="eyebrow">OVERVIEW</p><h1>Dashboard</h1><p class="muted">Welcome, <?= htmlspecialchars($_SESSION['username']) ?>.</p></div><a class="btn" href="sale.php">+ New sale</a></div>
  <section class="stats">
    <article class="stat"><span>Total products</span><strong><?= $productCount ?></strong></article>
    <article class="stat"><span>Units in stock</span><strong><?= $stockCount ?></strong></article>
    <article class="stat"><span>Sales today</span><strong>₱<?= number_format($todaySales, 2) ?></strong></article>
  </section>
  <section class="panel"><div class="panel-heading"><h2>Recent sales</h2><a href="sales.php">View all</a></div>
  <?php if (!$recent): ?><p class="muted">No sales yet. Record your first sale.</p><?php else: ?>
  <div class="table-wrap"><table><thead><tr><th>Product</th><th>Qty</th><th>Total</th><th>Date</th></tr></thead><tbody>
  <?php foreach ($recent as $sale): ?><tr><td><?= htmlspecialchars($sale['product_name']) ?></td><td><?= (int)$sale['quantity'] ?></td><td>₱<?= number_format($sale['total'],2) ?></td><td><?= htmlspecialchars($sale['sold_at']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div><?php endif; ?></section>
</main></body></html>
