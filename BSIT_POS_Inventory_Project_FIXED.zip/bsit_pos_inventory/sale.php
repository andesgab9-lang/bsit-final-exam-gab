<?php
require 'auth.php';
require 'config.php';
$message = ''; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = (int)($_POST['product_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 0);
    if ($quantity < 1) {
        $error = 'Quantity must be at least 1.';
    } else {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare('SELECT id, price, stock FROM products WHERE id=? FOR UPDATE');
            $stmt->execute([$productId]);
            $product = $stmt->fetch();
            if (!$product) {
                throw new RuntimeException('Product not found.');
            }
            if ($product['stock'] < $quantity) {
                throw new RuntimeException('Not enough stock available.');
            }
            $total = $product['price'] * $quantity;
            $stmt = $pdo->prepare('INSERT INTO sales (product_id,quantity,unit_price,total) VALUES (?,?,?,?)');
            $stmt->execute([$productId,$quantity,$product['price'],$total]);
            $stmt = $pdo->prepare('UPDATE products SET stock=stock-? WHERE id=?');
            $stmt->execute([$quantity,$productId]);
            $pdo->commit();
            $message = 'Sale recorded successfully. Total: ₱' . number_format($total,2);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to record sale.';
        }
    }
}
$products = $pdo->query('SELECT id,name,price,stock FROM products WHERE stock > 0 ORDER BY name')->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>New Sale | StorePOS</title><link rel="stylesheet" href="assets/style.css"></head><body>
<?php include 'nav.php'; ?><main class="container narrow"><div class="page-heading"><div><p class="eyebrow">TRANSACTION</p><h1>New sale</h1><p class="muted">Record a product purchase.</p></div></div>
<section class="panel"><?php if ($message): ?><div class="success"><?= htmlspecialchars($message) ?></div><?php endif; ?><?php if ($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if (!$products): ?><p class="muted">No products with available stock. Add stock in Products first.</p><?php else: ?>
<form method="post" class="stack">
<label>Choose product<select name="product_id" id="product" required><option value="">Select a product</option><?php foreach ($products as $p): ?><option value="<?= (int)$p['id'] ?>" data-price="<?= htmlspecialchars($p['price']) ?>" data-stock="<?= (int)$p['stock'] ?>"><?= htmlspecialchars($p['name']) ?> — ₱<?= number_format($p['price'],2) ?> (Stock: <?= (int)$p['stock'] ?>)</option><?php endforeach; ?></select></label>
<label>Quantity<input type="number" name="quantity" id="quantity" min="1" value="1" required></label>
<div class="sale-preview"><span>Estimated total</span><strong id="total">₱0.00</strong></div>
<button class="btn" type="submit">Complete sale</button></form><?php endif; ?></section></main>
<script>
const product = document.getElementById('product');
const quantity = document.getElementById('quantity');
const total = document.getElementById('total');
function updateTotal() {
  if (!product || !quantity) return;
  const option = product.options[product.selectedIndex];
  const price = Number(option?.dataset.price || 0);
  const qty = Math.max(0, Number(quantity.value || 0));
  total.textContent = '₱' + (price * qty).toFixed(2);
}
product?.addEventListener('change', updateTotal);
quantity?.addEventListener('input', updateTotal);
</script></body></html>
