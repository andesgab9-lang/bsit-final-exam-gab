# Simple POS and Inventory Management System

A beginner-friendly PHP + MySQL website project for a small store.

## Features
- Admin login
- Dashboard summary
- Add, edit, and delete products
- Record sales and automatically reduce stock
- View recent sales

## Requirements
- XAMPP (Apache + MySQL)
- PHP 8+
- A web browser

## Setup
1. Extract this folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** in XAMPP.
3. Open `http://localhost/phpmyadmin`.
4. Create/import the database by importing `database.sql`.
5. Visit `http://localhost/bsit_pos_inventory/`.
6. Sign in with:
   - Username: `admin`
   - Password: `admin123`

Change the default password before using this outside a school demo.

## Main architecture
- Browser: HTML/CSS forms and pages
- PHP: server-side logic, validation, authentication, and sales processing
- MySQL: stores users, products, and sales
- `config.php`: database connection
- `auth.php`: login protection

## GitHub upload
Create a new repository on GitHub, then from this folder run:
```bash
git init
git add .
git commit -m "Initial POS and inventory system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
Replace the URL with your own repository URL.
