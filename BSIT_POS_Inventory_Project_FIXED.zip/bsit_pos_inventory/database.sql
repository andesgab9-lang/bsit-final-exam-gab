CREATE DATABASE IF NOT EXISTS bsit_pos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bsit_pos;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  sku VARCHAR(50) NOT NULL UNIQUE,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  sold_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sales_product FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Demo account: username admin / password admin123
-- Hash generated for the password "admin123".
INSERT IGNORE INTO users (username, password_hash)
VALUES ('admin', '$2y$12$Rji1Nr12XgAHLEk.nQlxQuHVK8jhWJD2L3f6cDNsJYfujOFKQn4/m');

INSERT IGNORE INTO products (name, sku, price, stock) VALUES
('Notebook', 'NB-001', 35.00, 50),
('Ballpen', 'BP-001', 12.00, 100),
('Folder', 'FL-001', 18.00, 40);
