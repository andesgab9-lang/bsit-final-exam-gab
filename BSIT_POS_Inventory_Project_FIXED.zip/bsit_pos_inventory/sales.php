<?php
require 'auth.php';
require 'config.php';
$sales = $pdo->query('SELECT s.*, p.name AS product_name FROM sales s JOIN products p ON p.id=s.product_id ORDER BY s.sold_at DESC')->fetchAll();
$grandTotal = (float)$pdo->query('SELECT COALESCE(SUM(total),0) FROM sales')->fetchColumn();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sales | StorePOS</title><link rel="stylesheet" href="assets/style.css"></head><body>
<?php include 'nav.php'; ?><main class="container"><div class="page-heading"><div><p class="eyebrow">RECORDS</p><h1>Sales history</h1><p class="muted">All recorded transactions.</p></div><a class="btn" href="sale.php">+ New sale</a></div>
<section class="stat total-stat"><span>Total recorded sales</span><strong>₱<?= number_format($grandTotal,2) ?></strong></section>
<section class="panel"><div class="table-wrap"><table><thead><tr><th>Sale #</th><th>Product</th><th>Quantity</th><th>Unit price</th><th>Total</th><th>Date</th></tr></thead><tbody>
<?php foreach ($sales as $s): ?><tr><td>#<?= (int)$s['id'] ?></td><td><?= htmlspecialchars($s['product_name']) ?></td><td><?= (int)$s['quantity'] ?></td><td>₱<?= number_format($s['unit_price'],2) ?></td><td>₱<?= number_format($s['total'],2) ?></td><td><?= htmlspecialchars($s['sold_at']) ?></td></tr><?php endforeach; ?>
<?php if (!$sales): ?><tr><td colspan="6">No sales recorded yet.</td></tr><?php endif; ?></tbody></table></div></section></main></body></html>
