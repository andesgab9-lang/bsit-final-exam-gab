<?php
$host = 'localhost';
$db   = 'bsit_pos';
$user = 'root';
$pass = ''; // Default XAMPP MySQL password is usually blank.

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    exit('Database connection failed. Check config.php and make sure MySQL is running.');
}
